# Scanista Prompt Pro Landing Page

This repository hosts the landing page for **Scanista Prompt Pro** — a branded AI assistant experience.

## 🌐 Live Demo
Once GitHub Pages is enabled:
https://yourusername.github.io/scanista-prompt/

## 📂 Contents
- `index.html`: Main HTML file for the landing page
- `README.md`: This documentation
- `.gitignore`: Basic ignore rules for web projects

## ✨ Features
- Embedded Google Form for email-gated access
- Gumroad purchase button for paid upgrade
- Testimonials, benefits, and clear CTA layout
- Mobile-friendly and Netlify-compatible

## 🚀 How to Deploy on GitHub Pages
1. Fork or clone this repository
2. Replace/edit `index.html` as needed
3. Push to your GitHub repo
4. Go to Settings > Pages and set Source to `/root`

## 📬 Contact
Created by [Scanista QR](https://scanistaqr.com) — AI tools for business.
